<ul>

   <li><a href="https://www.facebook.com/marijasafa.timotijevic"><img src="img/face.png" width=30 height=30/></a></li>
   <li><a href="https://www.instagram.com"><img src="img/instagram.png"width=35 height=30/></a></li>
   <li><a href="rss.php"><img src="img/rss.png"width=30 height=30/></a></li>
   
    <li><a href="sitemap.xml"><i>sitemap</i></a></li>
  <li><span style="float:right;margin-top:10px;color:#5E5E5E;"><i>Copyright <img src="img/copy.png" width=20 height=20/>2016 Duca</i></span></li>
</ul>
<div class="cisti"></div>
